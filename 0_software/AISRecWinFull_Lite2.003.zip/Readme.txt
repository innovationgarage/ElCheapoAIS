Quick Guide

We assume that you have some experience in setting up VHF antennas with radios. 
You need a good position to maxmize the strength of the AIS signal and to eliminate possible
interference around the antenna.
Then you can follow this guide to quickly get AIS signals with AISRec.

Do not use AISrec for navigation as it is not intended for this use.
It can be a backup AIS receiver beside your main AIS receiver.
It could be a good receiver for base stations for marinetraffic, AIShub and etc.

1. Plug in your rtlsdr dongle. Cancel any auto driver installation by windows.

2. For Win XP, open zadig_xp_2.1.0.exe. For Win 7, Win 8, Win 8.1, Win 10, open zadig_2.1.2.exe.

3. Click Option->List All Devices->Find the dongle with USB ID 0BDA 2832 or 0BDA 2838 
	or any dongle ID you know-> Click install Driver.

4. For Win 7, Win 8, Win 8.1 and Win 10, install VS2013 runtime library by clicking vcredist_x86.exe
	in the VS2013 runtime library folder. 
	You can download the lastest version by accessing
	http://www.microsoft.com/en-us/download/details.aspx?id=40784
	You need the X86 library independent of your system, either X64 or X86.
	For XP, install VS2008 runtime library by clicking vcredist_x86.exe
	in the VS2008 runtime library folder.
	You can download the lastest version by accessing
	http://www.microsoft.com/en-us/download/details.aspx?id=29

5. For CPU with AVX2 capability, run the AISRecWinFull.exe in the AVX2 folder, such as I5.
	For CPU with SSE2 capability, such as Atom, run the AISRecWinFull.exe in the SSE2 folder.
	Especially for XP, run run the AISRecWinFull.exe in the XP folder.

6. The settings of AISRecWinFull.exe are described in another file.

7. For registration, open the about dialog and click the button "Appl. Code". 
	A application file "ApplCode.txt" will be created in the current folder.
	Send the file to us after contacting us about registration.
	You will receive a file "License.txt" and put it in the same folder to "ApplCode.txt".
	Run the receiver to check if it is successfully registered.

	Notice: You must have a network card with your device, either ethernet or wifi card.
	AISRec can run in the minimum mode without registration for maximum 20 minutes and 5000 messages.
	You can click it to rerun when it stops.

8. Registered users can get free updates without any more registration.

9. Set the ppm value of your dongle. It is 0 for all TCXO dongles. 
	It must be set for other dongles. 
	If you use "frequency shift" for frequncy correction as there is no ppm correctino for your dongle,
	you can calculate the value by 
	freqshift = the target frequency - the frequency value where the signal appears in the SDRSharp.
	No need for AISRec dongles as you can use the option "auto ppm correction".

10. You now can play around with your AISRec. More information will be released later.

11. You can report bugs by email. We will fix them sooner or later.
